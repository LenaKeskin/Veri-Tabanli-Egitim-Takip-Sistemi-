# ✅ Test Senaryoları

| No | Test Adı                    | Girdi                        | Beklenen Çıktı                               | Sonuç |
|----|-----------------------------|------------------------------|----------------------------------------------|-------|
| 1  | Veri Yükleme                | veri.xlsx                    | Tablo düzgün şekilde yüklenmeli              | ✅     |
| 2  | Sınıf filtresi çalışıyor mu | "10-A" seçildi               | Sadece 10-A sınıfına ait kayıtlar gelmeli    | ✅     |
| 3  | Boş filtre seçimi           | filtre boş bırakıldı         | Tüm veriler gösterilmeli                     | ✅     |
| 4  | Ortalama hesaplama doğru mu| Not verileri                 | Gerçek ortalamaya yakın bir sonuç            | ✅     |
| 5  | Grafik düzgün mü?           | Yüklü veri                   | Bar chart düzgün görünmeli                   | ✅     |
| 6  | Model skoru görüntüleniyor mu| ML kısmı çalıştırıldı       | Doğruluk skoru ekranda çıkmalı               | ✅     |
